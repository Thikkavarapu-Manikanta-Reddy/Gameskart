-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 08, 2019 at 07:19 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id3986382_gamezone`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `USERNO` int(200) NOT NULL,
  `ID` int(50) NOT NULL,
  `PRODUCT` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `PRICE` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `QUANTITY` int(50) NOT NULL,
  `AMOUNT` int(50) NOT NULL,
  `TOTAL` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`USERNO`, `ID`, `PRODUCT`, `PRICE`, `QUANTITY`, `AMOUNT`, `TOTAL`) VALUES
(5, 2, 'CALL OF DUTY WW2 PS4', 'RS.1099', 1, 1099, 1099),
(1, 6, 'MIRRORS EDGE EXTENDED PS4', 'RS.999', 1, 999, 999),
(1, 9, '	\r\nGOD OF WAR 3 EXTENDED PS3', 'RS.499', 1, 499, 499);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `NAME` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `EMAIL` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` int(50) NOT NULL,
  `PRODUCT` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `PRICE` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `AMOUNT` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `PRODUCT`, `PRICE`, `AMOUNT`) VALUES
(1, 'INFAMOUS SECOND SON PS4', 'RS.999', 999),
(2, 'CALL OF DUTY WW2 PS4', 'RS.1099', 1099),
(3, 'MSGV-THE PHANTOM PAIN PS4', 'RS.1099', 1099),
(4, 'SNIPER ELITE 4 EXTENDED PS4', 'RS.799', 799),
(5, 'UNTIL DAWN EXTENDED PS4', 'RS.1199', 1199),
(6, 'MIRRORS EDGE EXTENDED PS4', 'RS.999', 999),
(7, 'WATCH DOGS-EXTENDED PS3', 'RS.599', 599),
(8, 'GRAND THEFT AUTO V PS3', 'RS.1099', 1099),
(9, '	\r\nGOD OF WAR 3 EXTENDED PS3', 'RS.499', 499),
(10, 'DISHONORED-EXTENDED PS3', 'RS.799', 799),
(11, 'FAR CRY 4-EXTENDED PS3', 'RS.899', 899),
(12, 'UNCHARTED 3 EXTENDED PS3', 'RS.899', 899);

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `NAME` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `EMAIL` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `COMMENT` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`NAME`, `EMAIL`, `COMMENT`) VALUES
('jkhbsd', 'bfiaufb@dv', 'hbjbki'),
('', '', ''),
('', '', ''),
('', '', ''),
('manasa', 'manasa.mansi251@gmail.com', 'Superwebsite.');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `USERID` int(200) NOT NULL,
  `NAME` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `EMAIL` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `MOBILEPHONE` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `ADDRESS` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(500) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`USERID`, `NAME`, `EMAIL`, `MOBILEPHONE`, `ADDRESS`, `PASSWORD`) VALUES
(1, 't.manikantareddy', 't.manikantareddy160@gmail.com', '9629601733', 'Bangalore', 'Godofwar123'),
(2, 'manasa', 'manasa@gmail.com', '8904412341', 'Karur', 'Manasa123'),
(3, 'harish', 'njbu@kjni.com', '6166261', 'fwe', 'Hellohello123'),
(4, '', '', '', '', ''),
(5, 'manikanta', 'tmani@gmail.com', '5555555555', 'sastra', 'Abcdefgh@8'),
(6, 'a', '123456@ss.com', '000000000', 'gh', '12345678sS'),
(7, 'SAROJA', 'SAROJA123@gmail.com', '1234567890', 'Neekenduku ra', 'Saroja123'),
(8, 'abc@123', 'abc@123', '1234567890', 's', 'Ss123456'),
(9, 'happy', 's@2', '89', 'shdj', 'Saaaaaa8'),
(10, 'hariharan', 'hariharan@gmail.com', '7834561234', 'amalapuram', 'Godofwar321'),
(11, 'amit', 'amit@gmail.com', '9629601733', 'Karur', '@Amit123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`USERID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `USERID` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
